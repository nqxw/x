/**
 * Quest Completer — ShiggyCord / Vendetta
 * Port of Venus auto-quest engine:
 *  - enroll waiting quests
 *  - video progress (WATCH_VIDEO / WATCH_VIDEO_ON_MOBILE)
 *  - play-on-desktop heartbeats (PLAY_ON_DESKTOP)
 *  - activity heartbeats (PLAY_ACTIVITY)
 * Desktop super-properties + UA on play/activity requests only.
 */

const VIDEO_TASKS = ["WATCH_VIDEO_ON_MOBILE", "WATCH_VIDEO"];
const ACTIVITY_TASK = "PLAY_ACTIVITY";
const PLAY_TASK = "PLAY_ON_DESKTOP";
const QUEST_HOME_MOBILE = 12;
const VIDEO_LEEWAY = 10;
const VIDEO_POLL_MS = 5000;
const HEARTBEAT_MS = 60000;
const HEARTBEAT_TAIL_MS = 1000;
const MOBILE_ACTIVITY = 36;
const REFETCH_MS = 30 * 60 * 1000;
const REFETCH_JITTER_MS = 10 * 60 * 1000;
const RETRY_MS = 30 * 60 * 1000;
const REFUSED_MS = 6 * 60 * 60 * 1000;
const OFFLINE_MS = 5 * 60 * 1000;
const STALLED_BEATS = 5;
const SIGNATURE_BITS = [119, 108, 100, 91, 84, 75, 61, 55, 48, 38, 24, 11];

const DESKTOP = {
  version: "1.0.9265",
  build: 652418,
  native: 96160,
  electron: "42.11.15",
  chrome: "148.0.7778.280",
  osVersion: "10",
  osSdk: "19045"
};

const DESKTOP_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/" +
  DESKTOP.version +
  " Chrome/" +
  DESKTOP.chrome +
  " Electron/" +
  DESKTOP.electron +
  " Safari/537.36";

let storage;
let unsubs = [];
let timers = { scan: null, refetch: null };
let generation = 0;
let running = null;
let enrolling = false;
let userId = null;
let videoAt = new Map();
let completed = 0;
let lastStatus = "";
let lastError = "";
let desktopIdentity = { launch: null, signature: null, session: null, sessionAt: 0, locale: "en-US" };

function getApi() {
  return window.vendetta || window.bunny || window.kettu || {};
}

function findByProps(...props) {
  const api = getApi();
  if (api.metro?.findByProps) return api.metro.findByProps(...props);
  if (api.findByProps) return api.findByProps(...props);
  return null;
}

function findByStoreName(name) {
  const api = getApi();
  if (api.metro?.findByStoreName) return api.metro.findByStoreName(name);
  const Flux = findByProps("getStore", "Store");
  try {
    if (Flux?.getStore) return Flux.getStore(name);
  } catch (_) {}
  return findByProps("_dispatchToken", "getName") || null;
}

function later(fn, ms) {
  return setTimeout(fn, ms);
}

function sleep(ms) {
  return new Promise((r) => later(r, ms));
}

function enabled() {
  return !!(storage && storage.enabled !== false);
}

function opt(key, def) {
  if (!storage || storage[key] === undefined) return def;
  return storage[key];
}

function notify(msg) {
  lastStatus = msg || "";
  try {
    const api = getApi();
    if (api.logger) api.logger.log("[QuestCompleter]", msg);
  } catch (_) {}
}

function toast(content) {
  try {
    const api = getApi();
    if (api.ui?.toasts?.open) api.ui.toasts.open({ content });
    else if (api.toasts?.showToast) api.toasts.showToast(content);
  } catch (_) {}
}

function isAppActive() {
  try {
    const AppState = findByProps("currentState", "addEventListener");
    if (AppState?.currentState) return AppState.currentState === "active";
  } catch (_) {}
  return true;
}

function questStore() {
  return (
    findByStoreName("QuestStore") ||
    findByProps("quests", "getQuest") ||
    findByProps("quests")
  );
}

function httpClient() {
  return findByProps("get", "post", "put", "del") || findByProps("get", "post");
}

function hex(n) {
  let s = "";
  for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 16).toString(16);
  return s;
}

function uuidText(h) {
  return (
    h.slice(0, 8) +
    "-" +
    h.slice(8, 12) +
    "-" +
    h.slice(12, 16) +
    "-" +
    h.slice(16, 20) +
    "-" +
    h.slice(20, 32)
  );
}

function uuid() {
  const h = hex(32);
  return (
    h.slice(0, 12) +
    "4" +
    h.slice(13, 16) +
    "89ab"[Math.floor(Math.random() * 4)] +
    h.slice(17)
  );
}

function launchSignature() {
  const digits = uuid()
    .split("")
    .map((c) => parseInt(c, 16));
  for (const bit of SIGNATURE_BITS) {
    const i = 31 - Math.floor(bit / 4);
    digits[i] &= ~(1 << bit % 4);
  }
  return uuidText(digits.map((d) => d.toString(16)).join(""));
}

function base64(text) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const bytes = [];
  for (const c of unescape(encodeURIComponent(text))) bytes.push(c.charCodeAt(0));
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const n =
      (bytes[i] << 16) |
      ((bytes[i + 1] || 0) << 8) |
      (bytes[i + 2] || 0);
    out +=
      chars[(n >> 18) & 63] +
      chars[(n >> 12) & 63] +
      (i + 1 < bytes.length ? chars[(n >> 6) & 63] : "=") +
      (i + 2 < bytes.length ? chars[n & 63] : "=");
  }
  return out;
}

function desktopProperties() {
  const now = Date.now();
  if (!desktopIdentity.launch) desktopIdentity.launch = uuid();
  if (!desktopIdentity.signature) desktopIdentity.signature = launchSignature();
  if (!desktopIdentity.session || now - desktopIdentity.sessionAt > 30 * 60 * 1000) {
    desktopIdentity.session = uuid();
    desktopIdentity.sessionAt = now;
  }
  try {
    const i18n = findByProps("locale", "Messages");
    if (i18n?.locale) desktopIdentity.locale = i18n.locale;
  } catch (_) {}

  const properties = {
    os: "Windows",
    browser: "Discord Client",
    release_channel: "stable",
    client_version: DESKTOP.version,
    os_version: DESKTOP.osVersion,
    os_arch: "x64",
    app_arch: "x64",
    system_locale: desktopIdentity.locale,
    has_client_mods: false,
    client_launch_id: desktopIdentity.launch,
    browser_user_agent: DESKTOP_UA,
    browser_version: DESKTOP.electron,
    os_sdk_version: DESKTOP.osSdk,
    client_build_number: DESKTOP.build,
    native_build_number: DESKTOP.native,
    client_event_source: null,
    launch_signature: desktopIdentity.signature,
    client_heartbeat_session_id: desktopIdentity.session,
    client_app_state: "unfocused"
  };

  try {
    const enc = findByProps("encodeProperties");
    if (typeof enc?.encodeProperties === "function") {
      const encoded = enc.encodeProperties(properties);
      if (typeof encoded === "string" && encoded) return encoded;
    }
  } catch (_) {}
  return base64(JSON.stringify(properties));
}

function applyDesktopHeaders(request) {
  if (!request || typeof request.set !== "function") return;
  const props = desktopProperties();
  const phoneOnly = (key) =>
    key === "x-installation-id" || key === "x-fingerprint";
  const origSet = request.set.bind(request);
  request.set = function (name, original) {
    if (name && typeof name === "object") {
      const copy = {};
      for (const k of Object.keys(name)) {
        const low = String(k).toLowerCase();
        if (phoneOnly(low)) continue;
        if (low === "x-super-properties") copy[k] = props;
        else if (low === "user-agent") copy[k] = DESKTOP_UA;
        else if (low === "accept-language") copy[k] = desktopIdentity.locale;
        else copy[k] = name[k];
      }
      return origSet(copy);
    }
    const low = String(name).toLowerCase();
    if (phoneOnly(low)) return request;
    if (low === "x-super-properties") return origSet(name, props);
    if (low === "user-agent") return origSet(name, DESKTOP_UA);
    if (low === "accept-language") return origSet(name, desktopIdentity.locale);
    return origSet(name, original);
  };
}

async function questRequest(path, body, desktop, method) {
  const http = httpClient();
  const send = http && http[method || "post"];
  if (typeof send !== "function") throw new Error("HTTP client missing");

  const request = { url: path.startsWith("http") ? path : path };
  // Discord mobile often wants relative /api/v9/... — keep as path if client resolves
  if (!path.startsWith("http")) {
    request.url = path.startsWith("/") ? path : "/api/v9" + (path.startsWith("/") ? path : "/" + path);
  }
  if (body !== undefined) request.body = body;
  if (desktop) {
    request.onRequestCreated = (r) => applyDesktopHeaders(r);
    // Some clients take headers object directly
    request.headers = {
      "User-Agent": DESKTOP_UA,
      "X-Super-Properties": desktopProperties()
    };
  }

  return send.call(http, request);
}

function questFlag(store, key) {
  try {
    if (typeof store[key] === "boolean") return store[key];
    if (typeof store.get === "function") return store.get(key);
  } catch (_) {}
  return undefined;
}

function questList(store) {
  try {
    if (Array.isArray(store.quests)) return store.quests;
    if (store.quests && typeof store.quests === "object") return Object.values(store.quests);
    if (typeof store.getQuests === "function") return store.getQuests() || [];
  } catch (_) {}
  return [];
}

function taskOf(item) {
  const config = item?.config || item?.questConfig || item;
  const tasks = config?.taskConfigV2?.tasks || config?.tasks || config?.taskConfig?.tasks;
  if (!tasks) return null;
  const entries = Array.isArray(tasks) ? tasks : Object.values(tasks);
  for (const t of entries) {
    const type = t?.type || t?.id || t?.task_type;
    if (!type) continue;
    if (VIDEO_TASKS.includes(type)) return { type, kind: "video", target: Number(t.target || t.target_progress || 0) || 0 };
    if (type === PLAY_TASK) return { type, kind: "play", target: Number(t.target || t.target_progress || 0) || 1 };
    if (type === ACTIVITY_TASK) return { type, kind: "activity", target: Number(t.target || t.target_progress || 0) || 1 };
  }
  return null;
}

function progressOf(item, type) {
  try {
    const us = item.userStatus || item.user_status || {};
    const progress = us.progress || us.progressData || {};
    if (typeof progress[type] === "number") return progress[type];
    if (Array.isArray(progress)) {
      const hit = progress.find((p) => p.type === type || p.id === type);
      if (hit) return Number(hit.value || hit.progress || 0);
    }
  } catch (_) {}
  return 0;
}

function enrolledAt(item) {
  const us = item?.userStatus || item?.user_status || {};
  const t = us.enrolledAt || us.enrolled_at;
  if (!t) return NaN;
  const n = typeof t === "number" ? t : Date.parse(t);
  return Number.isFinite(n) ? n : NaN;
}

function isCompleted(item, task) {
  if (!task) return false;
  const us = item?.userStatus || item?.user_status || {};
  if (us.completedAt || us.completed_at) return true;
  return progressOf(item, task.type) >= (task.target || 1);
}

function isEnrolled(item) {
  const us = item?.userStatus || item?.user_status || {};
  return !!(us.enrolledAt || us.enrolled_at || us.enrolled);
}

function enrollBody(id) {
  return {
    location: QUEST_HOME_MOBILE,
    is_targeted: false,
    metadata: null,
    quest_id: id
  };
}

function schedule(ms) {
  if (timers.scan != null) clearTimeout(timers.scan);
  timers.scan = later(() => {
    timers.scan = null;
    scan();
  }, ms);
}

function stopAll(hard) {
  generation++;
  running = null;
  enrolling = false;
  if (timers.scan != null) clearTimeout(timers.scan);
  if (timers.refetch != null) clearTimeout(timers.refetch);
  timers.scan = null;
  timers.refetch = null;
  if (hard) {
    videoAt.clear();
    completed = 0;
  }
  notify("stopped");
}

function start(delay) {
  if (!enabled()) return;
  if (timers.refetch == null) {
    const jitter = Math.floor(Math.random() * REFETCH_JITTER_MS);
    timers.refetch = later(() => {
      timers.refetch = null;
      if (enabled()) {
        fetchQuests(true).finally(() => start(0));
      }
    }, REFETCH_MS + jitter);
  }
  schedule(delay != null ? delay : 1500 + Math.floor(Math.random() * 1500));
}

async function fetchQuests(force) {
  try {
    await questRequest("/quests/@me", undefined, false, "get");
  } catch (_) {}
}

function activeEntry(entry) {
  return running === entry && entry.generation === generation && enabled();
}

function terminate(entry) {
  if (running === entry) {
    running = null;
  }
  if (entry && entry.generation === generation) {
    schedule(2000 + Math.floor(Math.random() * 2000));
  }
}

async function doEnroll(item) {
  const id = item.id || item.questId || item.quest_id;
  if (!id || enrolling) return;
  enrolling = true;
  const gen = generation;
  try {
    const response = await questRequest(
      "/quests/" + id + "/enroll",
      enrollBody(id),
      false,
      "post"
    );
    if (gen !== generation || !enabled()) return;
    notify("enrolled " + id);
    toast("Quest enrolled");
    schedule(3000 + Math.floor(Math.random() * 2000));
  } catch (e) {
    lastError = String(e && e.message ? e.message : e);
    notify("enroll failed: " + lastError);
    schedule(OFFLINE_MS);
  } finally {
    enrolling = false;
  }
}

async function runVideo(entry, item) {
  const enrolled = enrolledAt(item);
  const target = entry.task.target || 1;
  if (!Number.isFinite(enrolled)) throw new Error("no accepted time");

  let done = Math.max(progressOf(item, entry.task.type), videoAt.get(entry.id) || 0);
  let played = 0;
  let tick = Date.now();
  const from = done;

  while (activeEntry(entry) && done < target) {
    if (!isAppActive()) {
      entry.paused = true;
      return false;
    }
    const next = Math.min(target, done + 6 + Math.random() * 2);
    const now = Date.now();
    played += now - tick;
    tick = now;
    const playing = Math.min(
      (now - enrolled) / 1000 + VIDEO_LEEWAY,
      from + played / 1000
    );
    if (playing < next) {
      await sleep(Math.min(VIDEO_POLL_MS, Math.max(250, Math.ceil((next - playing) * 1000))));
      continue;
    }
    const timestamp = Math.min(target, playing);
    try {
      await questRequest("/quests/" + entry.id + "/video-progress", { timestamp }, false, "post");
    } catch (e) {
      lastError = String(e && e.message ? e.message : e);
      break;
    }
    if (!activeEntry(entry)) return false;
    done = timestamp;
    if (videoAt.size >= 64) videoAt.delete(videoAt.keys().next().value);
    videoAt.set(entry.id, done);
    notify("video " + Math.floor(done) + "/" + target);
  }
  if (done >= target) {
    completed++;
    toast("Video quest done");
    return true;
  }
  return false;
}

async function runHeartbeat(entry, item, kind) {
  const target = entry.task.target || 1;
  let done = progressOf(item, entry.task.type);
  let beats = 0;
  let stalled = 0;
  let lastProg = done;

  while (activeEntry(entry) && done < target) {
    const body =
      kind === "activity"
        ? {
            stream_key: null,
            terminal: false,
            // activity-style payload
          }
        : {
            // play-on-desktop style
            terminal: false
          };

    // Prefer the documented heartbeat endpoints used by desktop
    const path =
      kind === "activity"
        ? "/quests/" + entry.id + "/heartbeat"
        : "/quests/" + entry.id + "/heartbeat";

    try {
      const res = await questRequest(path, body, true, "post");
      beats++;
      // best-effort progress read
      try {
        const store = questStore();
        const list = questList(store);
        const fresh = list.find((q) => (q.id || q.questId) === entry.id);
        if (fresh) done = progressOf(fresh, entry.task.type);
      } catch (_) {}

      if (done <= lastProg) stalled++;
      else stalled = 0;
      lastProg = done;

      if (stalled >= STALLED_BEATS) {
        notify("stalled, rotating");
        break;
      }
      notify(kind + " beat " + beats + " prog " + done + "/" + target);
    } catch (e) {
      lastError = String(e && e.message ? e.message : e);
      notify(kind + " fail: " + lastError);
      await sleep(OFFLINE_MS);
      continue;
    }

    if (!activeEntry(entry)) return false;
    if (done >= target) break;
    await sleep(HEARTBEAT_MS + Math.floor(Math.random() * HEARTBEAT_TAIL_MS));
  }

  if (done >= target) {
    completed++;
    toast((kind === "activity" ? "Activity" : "Play") + " quest done");
    return true;
  }
  return false;
}

async function openQuest(item) {
  const task = taskOf(item);
  if (!task) return;
  if (task.kind === "video" && !opt("video", true)) return;
  if (task.kind === "play" && !opt("play", true)) return;
  if (task.kind === "activity" && !opt("activity", true)) return;

  const id = item.id || item.questId || item.quest_id;
  const entry = {
    id,
    task,
    generation,
    paused: false,
    startedAt: Date.now()
  };
  running = entry;
  notify("running " + task.kind + " " + id);

  try {
    let ok = false;
    if (task.kind === "video") ok = await runVideo(entry, item);
    else if (task.kind === "play") ok = await runHeartbeat(entry, item, "play");
    else if (task.kind === "activity") ok = await runHeartbeat(entry, item, "activity");
    if (ok) schedule(2000);
  } catch (e) {
    lastError = String(e && e.message ? e.message : e);
    notify("run error: " + lastError);
  } finally {
    if (running === entry) running = null;
    if (entry.generation === generation) schedule(2500 + Math.floor(Math.random() * 2000));
  }
}

function scan() {
  if (!enabled()) return;
  if (running) return;

  const store = questStore();
  if (!store) {
    schedule(5000);
    return;
  }

  if (questFlag(store, "isQuestAccessSuspended") === true) {
    lastError = "quest access suspended";
    notify(lastError);
    return;
  }

  let all = questList(store);
  if (!all.length) {
    schedule(15000);
    return;
  }

  const waiting = [];
  const ready = [];

  for (const item of all) {
    const task = taskOf(item);
    if (!task) continue;
    if (isCompleted(item, task)) continue;

    if (!isEnrolled(item)) {
      if (opt("enroll", true)) waiting.push(item);
      continue;
    }

    // Video only while app focused; play/activity can run background
    if (task.kind === "video") {
      if (!isAppActive()) continue;
      if (!opt("video", true)) continue;
    } else if (task.kind === "play" && !opt("play", true)) continue;
    else if (task.kind === "activity" && !opt("activity", true)) continue;

    ready.push({ item, task });
  }

  // Prefer play/activity over video when background
  ready.sort((a, b) => {
    const rank = (k) => (k === "play" || k === "activity" ? 0 : 1);
    return rank(a.task.kind) - rank(b.task.kind);
  });

  if (waiting.length && opt("enroll", true) && isAppActive() && !enrolling) {
    doEnroll(waiting[0]);
    return;
  }

  if (ready.length) {
    openQuest(ready[0].item);
    return;
  }

  schedule(10000 + Math.floor(Math.random() * 5000));
}

function onConnection(payload) {
  try {
    const id = payload?.user?.id;
    if (id && userId && id !== userId) {
      stopAll(true);
    }
    if (id) userId = id;
  } catch (_) {}
  if (enabled()) start(8000);
}

function onLogout() {
  stopAll(true);
  userId = null;
}

function wireFlux() {
  const api = getApi();
  const Flux =
    api.flux ||
    findByProps("dispatch", "subscribe") ||
    findByProps("dirtyDispatch", "subscribe");

  if (!Flux || typeof Flux.subscribe !== "function") return false;

  const u1 = Flux.subscribe("CONNECTION_OPEN", onConnection);
  const u2 = Flux.subscribe("LOGOUT", onLogout);
  const u3 = Flux.subscribe("APP_STATE_UPDATE", (e) => {
    if (e?.state === "active" && userId && enabled()) {
      schedule(2000 + Math.floor(Math.random() * 3000));
    }
  });

  unsubs.push(
    typeof u1 === "function" ? u1 : () => Flux.unsubscribe?.("CONNECTION_OPEN", onConnection)
  );
  unsubs.push(
    typeof u2 === "function" ? u2 : () => Flux.unsubscribe?.("LOGOUT", onLogout)
  );
  unsubs.push(
    typeof u3 === "function"
      ? u3
      : () => Flux.unsubscribe?.("APP_STATE_UPDATE", () => {})
  );
  return true;
}

export default {
  onLoad() {
    const api = getApi();
    storage = api.plugin?.storage;
    if (!storage || typeof storage !== "object") {
      storage = {
        enabled: true,
        enroll: true,
        video: true,
        play: true,
        activity: true
      };
    }
    if (storage.enabled === undefined) storage.enabled = true;
    if (storage.enroll === undefined) storage.enroll = true;
    if (storage.video === undefined) storage.video = true;
    if (storage.play === undefined) storage.play = true;
    if (storage.activity === undefined) storage.activity = true;

    wireFlux();
    if (enabled()) {
      // Discord may already be connected
      start(5000);
    }
    notify("loaded");
  },

  onUnload() {
    stopAll(true);
    for (const u of unsubs) {
      try {
        u();
      } catch (_) {}
    }
    unsubs = [];
  }
};

export function getSettings() {
  const React = window.React || getApi().metro?.common?.React;
  const Forms = getApi().metro?.common?.Forms || {};
  const { FormSection, FormSwitch, FormRow } = Forms;
  if (!React || !FormSection) return () => null;

  return () => {
    const s = storage || {};
    return React.createElement(
      FormSection,
      { title: "Quest Completer" },
      React.createElement(FormSwitch, {
        label: "Enabled",
        subLabel: "Auto enroll + complete quests",
        value: !!s.enabled,
        onValueChange: (v) => {
          s.enabled = v;
          if (v) start(1000);
          else stopAll(false);
          toast(v ? "Quest completer on" : "Quest completer off");
        }
      }),
      React.createElement(FormSwitch, {
        label: "Auto enroll",
        value: s.enroll !== false,
        onValueChange: (v) => {
          s.enroll = v;
        }
      }),
      React.createElement(FormSwitch, {
        label: "Video quests",
        value: s.video !== false,
        onValueChange: (v) => {
          s.video = v;
        }
      }),
      React.createElement(FormSwitch, {
        label: "Play on desktop",
        value: s.play !== false,
        onValueChange: (v) => {
          s.play = v;
        }
      }),
      React.createElement(FormSwitch, {
        label: "Activity quests",
        value: s.activity !== false,
        onValueChange: (v) => {
          s.activity = v;
        }
      }),
      React.createElement(FormRow, {
        label: "Status",
        subLabel: (lastError ? "err: " + lastError + " · " : "") + (lastStatus || "idle") + " · done " + completed
      })
    );
  };
}
